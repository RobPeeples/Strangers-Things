
import React from 'react';
import ReactDOM from 'react-dom';

const App = () => {
  return <div className="app">
    React BoilerPlate
  </div>
}

ReactDOM.render(
  <App />,
  document.getElementById('app')
);