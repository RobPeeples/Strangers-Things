# react-starter-template
Template used to create a simple react application
